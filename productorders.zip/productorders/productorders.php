<?php
/**
* 2007-2016 PrestaShop.
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2016 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

if (!defined('_PS_VERSION_'))
  exit;
 
 include_once(_PS_MODULE_DIR_.'productorders/classes/ProductOrder.php');
  
  class ProductOrders extends Module
  
  {
   
  public function __construct()
  {
    $this->name = 'productorders';
    $this->tab = 'administration';
    $this->version = '1.0.0';
    $this->author = 'InnovativesLabs';
    $this->need_instance = 0;
	$this->secure_key = Tools::encrypt($this->name);
    $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
    $this->bootstrap = true;
	
 
    parent::__construct();
 
    $this->displayName = $this->l('Product Orders');
    $this->description = $this->l('Product List With Assigned Orders');
 
    $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
    
  }    
	  public function install()
	{
	  if (Shop::isFeatureActive())
		Shop::setContext(Shop::CONTEXT_ALL);
	 
	  if (!parent::install())
		return false; 	
		
	  return true;
	}   
	
       public function uninstall()
    {
        if (!parent::uninstall()     
            )
                return false;
        
           return true;
    }
  
        public function getContent()
    {
           $output = null;
		   if (Tools::isSubmit('viewproduct') && Tools::isSubmit('id'))
		{
		$output.=$this->renderOrders().'</br>'.$this->InnovativesLabs();		
		}
		   
		else
       {		
		   $output.=$this->renderList().'</br>'.$this->InnovativesLabs();
       }	
            return $output;
			
    }	     
  
  	public function renderList()
	{
		$fields_list = array(
		
		   'id_order' => array(
				'title' => $this->l('ID Order'),
				'search' => false,
			),
			'id' => array(
				'title' => $this->l('ID Product'),
				'search' => false,
			),			
			'name' => array(
				'title' => $this->l('Product Name'),
				'search' => false,
			)
		);

		if (!Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE'))
			unset($fields_list['shop_name']);
		$helper_list = New HelperList();
		$helper_list->module = $this;
		$helper_list->title = $this->l('Ordered Products List');
		$helper_list->shopLinkType = '';
		$helper_list->no_link = true;
		$helper_list->show_toolbar = true;
		$helper_list->simple_header = false;
		$helper_list->identifier = 'id';
		$helper_list->table = 'product';
		$helper_list->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name;
		$helper_list->token = Tools::getAdminTokenLite('AdminModules');
		$helper_list->actions = array('view');
		$helper_list->bulk_actions = array(
			'select' => array(
				'text' => $this->l('Change order status'),
				'icon' => 'icon-refresh',				
			)
		); 		

		// This is needed for displayEnableLink to avoid code duplication
		$this->_helperlist = $helper_list;

		/* Retrieve list data */
		$order=new ProductOrder();
		$orders=$order->getAllProductOrders();
		$helper_list->listTotal = count($order->getAllProductOrders());

		/* Paginate the result */
		$page = ($page = Tools::getValue('submitFilter'.$helper_list->table)) ? $page : 1;
		$pagination = ($pagination = Tools::getValue($helper_list->table.'_pagination')) ? $pagination : 50;
		$orders = $this->paginateOrderProducts($orders, $page, $pagination);

		return $helper_list->generateList($orders, $fields_list);
		
	}
  
   public function paginateOrderProducts($orders, $page = 1, $pagination = 50)
	{
		if(count($orders) > $pagination)
			$orders= array_slice($orders, $pagination * ($page - 1), $pagination);

		return $orders;
	}  
  
  public function renderOrders(){
  
    $id_product=Tools::getValue('id');
    $orders=new ProductOrder();	
    $this->context->smarty->assign(
      array(
	      
		  'id_product'=>Tools::getValue('id'),
		  'count'=>count($orders->getProductOrders()),
          'product_orders'=>$orders->getProductOrders(),	
          'token'=>Tools::getAdminTokenLite('AdminOrders'), 		  
		  'url_back'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules')
		  
          
            )
               );  
  
  return $this->display(__FILE__, 'update_productorders.tpl');
  }
  
  
      public function InnovativesLabs(){	  
		return $this->display(__FILE__, 'innovativeslabs.tpl');	
	  }  
  
  
}
  

