<?php

if (!defined('_PS_VERSION_'))
	exit;
class HomeVideo extends Module 
 {
		
	public function __construct()
	{
		$this->name = 'homevideo';
		$this->tab = 'front_office_features';
		$this->version = '1.0.0';
		$this->author = 'InnovativesLabs';
		$this->need_instance = 0;
		$this->secure_key = Tools::encrypt($this->name);		
		$this->bootstrap = true;
		
		parent::__construct();

		$this->displayName = $this->l('Home Video');
		$this->description = $this->l('Post a Video in your  home page.');
		$this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
	}

	public function install()
	{
		if (!parent::install() ||               
			!$this->registerHook('displayHomeTab') ||
            !$this->registerHook('displayHomeTabContent') ||
			!$this->registerHook('header') 
			
		)
			return false;		
		return true;
	}


	public function uninstall()
	{	
			
		Configuration::deleteByName('VIDEO_DESC');
		$this->emptyUload();
		return parent::uninstall();
	}
	
	

	public function getContent()
	{	
		return $this->postProcess().$this->renderForm().'</br>'.$this->display(__FILE__, 'homevideo.tpl');		
	}
   
   public function renderForm()
	{
		$fields_form = array(
			'form' => array(
				'legend' => array(
					'title' => $this->l('Settings'),
					'icon' => 'icon-cogs'
				),
				'input' => array(
					array(
						'type' => 'file',
						'label' => $this->l('Video URL'),
						'name' => 'VIDEO_URL',
						'desc' => $this->l('Upload an video from your Computer.'),
						'lang' => false,
					),					
					array(
						'type' => 'text',
						'lang' => false,
						'label' => $this->l('Video label'),
						'name' => 'VIDEO_DESC',
						'desc' => $this->l('Please enter a label for this video.')
					)
				),
				'submit' => array(
					'title' => $this->l('Save')
				)
			),
		);

		$helper = new HelperForm();
		$helper->show_toolbar = false;
		$helper->table =  $this->table;
		$lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
		$helper->default_form_language = $lang->id;
		$helper->module = $this;
		$helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
		$helper->identifier = $this->identifier;
		$helper->submit_action = 'submitStoreConf';
		$helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->tpl_vars = array(
			'uri' => $this->getPathUri(),
			'fields_value' => $this->getConfigFieldsValues(),
			'languages' => $this->context->controller->getLanguages(),
			'id_language' => $this->context->language->id
		);

		return $helper->generateForm(array($fields_form));
	}
   
   public function getConfigFieldsValues()
	{
		
		$fields = array();			
		$fields['VIDEO_DESC']= Tools::getValue('VIDEO_DESC', Configuration::get('VIDEO_DESC'));		
        $fields['VIDEO_URL']=Tools::getValue('VIDEO_URL', Configuration::get('VIDEO_URL'));
		return $fields;
	}
   
   
   public function hookDisplayHomeTab($params)
{
    return $this->display(__FILE__, 'tab.tpl');
}


public function hookDisplayHomeTabContent($params)
{
   
 

    $this->context->smarty->assign(array( 	
    'nka_annonce_list' => 'InnovativesLabs Web Agency',
	'video_url'=>Configuration::get('VIDEO_URL'),	
	'video_desc'=>Configuration::get('VIDEO_DESC'),
	'mod_dir'=>'modules/homevideo/upload/'
    		
));
    return $this->display(__FILE__, 'tab_content.tpl');
} 

public function postProcess()
	{
		if (Tools::isSubmit('submitStoreConf'))
		{
			$languages = Language::getLanguages(false);
			$values = array();
			$update_images_values = false;
			
				if (isset($_FILES['VIDEO_URL'])
					&& isset($_FILES['VIDEO_URL']['tmp_name'])
					&& !empty($_FILES['VIDEO_URL']['tmp_name']))
				{
					if ($_FILES['VIDEO_URL']['size']>400000000)
						return $this->displayError($this->l('file to heavy choose another one.'));
					else
					{
						$ext = substr($_FILES['VIDEO_URL']['name'], strrpos($_FILES['VIDEO_URL']['name'], '.') + 1);
						$file_name = md5($_FILES['VIDEO_URL']['name']).'.'.$ext;				


						if (!move_uploaded_file($_FILES['VIDEO_URL']['tmp_name'], dirname(__FILE__).DIRECTORY_SEPARATOR.'upload'.DIRECTORY_SEPARATOR.$file_name))
							return $this->displayError($this->l('An error occurred while attempting to upload the file.'));
						else
						{
							if (Configuration::get('VIDEO_URL') != $file_name)
								@unlink(dirname(__FILE__).DIRECTORY_SEPARATOR.'upload'.DIRECTORY_SEPARATOR.Configuration::get('VIDEO_URL'));

							$values['VIDEO_URL']= $file_name;
						}
					}

					$update_images_values = true;
				}               
				
				$values['VIDEO_DESC']= Tools::getValue('VIDEO_DESC');
			

			if ($update_images_values)
			Configuration::updateValue('VIDEO_URL', $values['VIDEO_URL']);			
			Configuration::updateValue('VIDEO_DESC', $values['VIDEO_DESC']);

			$this->_clearCache('tab_content.tpl');
			return $this->displayConfirmation($this->l('The settings have been updated.'));
		}
		return '';
	}

  public function emptyUload(){  
  if(Configuration::get('VIDEO_URL')!='')
  {@unlink(dirname(__FILE__).DIRECTORY_SEPARATOR.'upload'.DIRECTORY_SEPARATOR.Configuration::get('VIDEO_URL'));
  
  }
  Configuration::deleteByName('VIDEO_URL');	
  
  }
  
 

}	
	