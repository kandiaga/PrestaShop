<?php
if (!defined('_PS_VERSION_'))
  exit;
  
  class PopUpMessage extends Module
  
  {  
  
	  public function __construct()
	  {
		$this->name = 'popupmessage';
		$this->tab = 'front_office_features';
		$this->version = '1.0';
		$this->author = 'InnovativesLabs';
		$this->need_instance = 0;
		$this->ps_versions_compliancy = array('min' => '1.6', 'max'=> _PS_VERSION_);
		$this->bootstrap = true;
	 
		parent::__construct();
	 
		$this->displayName = $this->l('Prestashop PopUp Message');
		$this->description = $this->l('This a pop up message  for your shop ');
	 
		$this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
	 
		if (!Configuration::get('POPUPMESSAGE_TEXT'))      
		  $this->warning = $this->l('No name provided');
	  }
  
  
  
	  public function install()
	{
	  if (Shop::isFeatureActive())
		Shop::setContext(Shop::CONTEXT_ALL);
	 
	  if (!parent::install() ||    
		!$this->registerHook('header') ||	       		
		!$this->registerHook('displayTop')||
		!Configuration::updateValue('DISPLAY_POPUP_MESSAGE', 1) 
		
		
	  )
		return false;
	 
	  return true;
	}


       public function uninstall()
    {
		
		@unlink(dirname(__FILE__).DIRECTORY_SEPARATOR.'images'.DIRECTORY_SEPARATOR.Configuration::get('POPUPMESSAGE_IMG'));
        if (!parent::uninstall() ||
         !Configuration::deleteByName('POPUPMESSAGE_TEXT')||
		 !Configuration::deleteByName('POPUPMESSAGE_IMG')||
		 !Configuration::deleteByName('START_DATE')||
		 !Configuration::deleteByName('END_DATE')||
		 !Configuration::deleteByName('POPUPMESSAGE_WIDTH')||
		 !Configuration::deleteByName('POPUPMESSAGE_HEIGHT')||
		 !Configuration::deleteByName('DISPLAY_POPUP_MESSAGE')
		 
           )
                return false; 
           return true;
    }
  
        public function getContent()
    {
           $output = null;
 
          if (Tools::isSubmit('submit'.$this->name))
      {
        $message_text = strval(Tools::getValue('POPUPMESSAGE_TEXT'));
		$message_img = strval(Tools::getValue('POPUPMESSAGE_IMG'));
		$start_date=strval(Tools::getValue('START_DATE'));
		$end_date=strval(Tools::getValue('END_DATE'));
		$message_display=(int)(Tools::getValue('DISPLAY_POPUP_MESSAGE'));
		$message_width=strval(Tools::getValue('POPUPMESSAGE_WIDTH'));
		$message_height=strval(Tools::getValue('POPUPMESSAGE_HEIGHT'));
						
        if ( empty($message_text) && empty($message_img)  && !Validate::isGenericName($message_text)  && !Validate::isGenericName($message_img))		
		
            $output .= $this->displayError($this->l('No PopUpMessage Text or  PopUpMessage Image provided. Please provide a text  or image to display .'));
        else
        {
			$this->postProcess();
            Configuration::updateValue('POPUPMESSAGE_TEXT', $message_text);	  					
			Configuration::updateValue('DISPLAY_POPUP_MESSAGE', $message_display) ;
			Configuration::updateValue('POPUPMESSAGE_WIDTH', $message_width);
			Configuration::updateValue('POPUPMESSAGE_HEIGHT', $message_height);
			
			Configuration::updateValue('START_DATE', $start_date);
			Configuration::updateValue('END_DATE', $end_date);		
			
            $output .= $this->displayConfirmation($this->l('Settings updated'));
				     
        }
      }
            return $output.$this->displayForm() .'<br/>'.$this->InnovativesLabs();
    }
	
	
	
		   public function displayForm()
	  {
		// Get default language
		$default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
		 
		// Init Fields form array
		$fields_form[0]['form'] = array(
			'legend' => array(
				'title' => $this->l('PopUp Message  Settings'),
			),
			'input' => array(		
			
			
			array(
							'type' => 'switch',
							'label' => $this->l('Display PopUp Message'),
							'name' => 'DISPLAY_POPUP_MESSAGE',
							'desc' => $this->l('Activate the PopP Message to be seen in your home page.'),
							'values' => array(
										array(
											'id' => 'active_on',
											'value' => 1,
											'label' => $this->l('Enabled')
										),
										array(
											'id' => 'active_off',
											'value' => 0,
											'label' => $this->l('Disabled')
										)
									),
						),
			
				array('type' => 'text',							
								'label' => $this->l('Start Date'),
								'name' => 'START_DATE',
								'desc' => $this->l('Please enter a start date of this advertizement in format:  25.11.2015')
								
							),
				
				array('type' => 'text',							
								'label' => $this->l('End Date'),
								'name' => 'END_DATE',
								'desc' => $this->l('Please enter a End date of this advertizement in format:  25.11.2015')
					 ),	

				array('type' => 'text',							
								'label' => $this->l('Message Width'),
								'name' => 'POPUPMESSAGE_WIDTH',
								'desc' => $this->l('Please enter the width to specify your display size.')
					 ),	
					 
				array('type' => 'text',							
								'label' => $this->l('Message Height'),
								'name' => 'POPUPMESSAGE_HEIGHT',
								'desc' => $this->l('Please enter the height to specify your display size.')
					 ),		 				 
				
			
				array(
					'type' => 'textarea',
					'label' => $this->l('Your PopUpMessage Text'),
					'name' => 'POPUPMESSAGE_TEXT',                
					'required' => false,
					'autoload_rte'=>true,
					
				),			
				array(
							'type' => 'file',
							'label' => $this->l('PopUpMessage Image'),
							'name' => 'POPUPMESSAGE_IMG',
							'desc' => $this->l('Upload an image for your PopUpMessage.'),	
												
						)
				
				
				
			),
			'submit' => array(
				'title' => $this->l('Save'),
				'class' => 'button'
			)
		);
		 
		$helper = new HelperForm();
		 
		// Module, token and currentIndex
		$helper->module = $this;
		$helper->name_controller = $this->name;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
		 
		// Language
		$helper->default_form_language = $default_lang;
		$helper->allow_employee_form_lang = $default_lang;
		 
		// Title and toolbar
		$helper->title = $this->displayName;
		$helper->show_toolbar = true;        // false -> remove toolbar
		$helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
		$helper->submit_action = 'submit'.$this->name;
		$helper->toolbar_btn = array(
			'save' =>
			array(
				'desc' => $this->l('Save'),
				'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
				'&token='.Tools::getAdminTokenLite('AdminModules'),
			),
			'back' => array(
				'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
				'desc' => $this->l('Back to list')
			)
		);
		 
		// Load current value
		$helper->fields_value['POPUPMESSAGE_TEXT'] = Configuration::get('POPUPMESSAGE_TEXT');
		$helper->fields_value['POPUPMESSAGE_IMG'] = Configuration::get('POPUPMESSAGE_IMG');
		$helper->fields_value['START_DATE'] = Configuration::get('START_DATE');
		$helper->fields_value['END_DATE'] = Configuration::get('END_DATE');
		$helper->fields_value['DISPLAY_POPUP_MESSAGE'] = Configuration::get('DISPLAY_POPUP_MESSAGE');
		$helper->fields_value['POPUPMESSAGE_WIDTH'] = Configuration::get('POPUPMESSAGE_WIDTH');
		$helper->fields_value['POPUPMESSAGE_HEIGHT'] = Configuration::get('POPUPMESSAGE_HEIGHT');		
		
		 
		return $helper->generateForm($fields_form);
		}
  
	   
	   
   
    public function hookDisplayHeader()
   {       
     $this->context->controller->addCSS($this->_path.'css/popupmessage.css', 'all');		
	$this->context->controller->addJS($this->_path.'js/popupmessage.js', 'all');	
		
   }  
	
	public function hookdisplayTop($params)
	{
		if($this->isTiming()==true  && $this->messageActive()==true){
		$this->smarty->assign(array(
		         'start_date'=>Configuration::get('START_DATE'),
				 'end_date'=>Configuration::get('END_DATE'),
		         'message_img' =>Configuration::get('POPUPMESSAGE_IMG'),
				'message_name' =>Configuration::get('POPUPMESSAGE_TEXT'),
				'message_width'=> Configuration::get('POPUPMESSAGE_WIDTH'), 
				'message_height'=> Configuration::get('POPUPMESSAGE_HEIGHT')				
			));
		return $this->display(__FILE__, 'popupmessage.tpl');
		}
		
		else return  '';
		
	}

	public function postProcess()
	{
			if (Tools::isSubmit('submitpopupmessage'))
			{			
			if (isset($_FILES['POPUPMESSAGE_IMG']) && isset($_FILES['POPUPMESSAGE_IMG']) && !empty($_FILES['POPUPMESSAGE_IMG']))
					{
						if ($error = ImageManager::validateUpload($_FILES['POPUPMESSAGE_IMG'], 4000000))
							return $error;
						else
						{
							$ext = substr($_FILES['POPUPMESSAGE_IMG']['name'], strrpos($_FILES['POPUPMESSAGE_IMG']['name'], '.') + 1);
							$file_name = md5($_FILES['POPUPMESSAGE_IMG']['name']).'.'.$ext;

							if (!move_uploaded_file($_FILES['POPUPMESSAGE_IMG']['tmp_name'], dirname(__FILE__).DIRECTORY_SEPARATOR.'images'.DIRECTORY_SEPARATOR.$file_name))
								return $this->displayError($this->l('An error occurred while attempting to upload the file.'));
							else
							{	
						       						
								Configuration::updateValue('POPUPMESSAGE_IMG',$file_name);							
							}
						}					
					}			
			}
			return '';
	}
	
	
	public function isTiming(){
		
				
		$rep=false;
		$start=Configuration::get('START_DATE');
		$end=Configuration::get('END_DATE');		
		$actual_date=date('d.m.y');
		
		if( strtotime($start)<=strtotime($actual_date)  &&  strtotime($actual_date)<= strtotime($end)){			
			$rep=true;
		} 
		else 
		{$rep=false;}
		
		return $rep;		
		
	}
	
	
	public function messageActive(){		$message=false;		
		$message = (Configuration::get('DISPLAY_POPUP_MESSAGE') == 1 ? true : false);		
		return $message;
		
		
	}
	
	
	public function InnovativesLabs(){		
		
		return $this->display(__FILE__, 'innovativeslabs.tpl');
		
	} 
	 
  
  
  }



